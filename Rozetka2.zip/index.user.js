(function(){
    let sidebar = document.querySelector('aside.sidebar');
    let items = sidebar[0].querySelectorAll('li.checkbox-filter__item');

    items[0].querySelector('a').addEventListener('click', function(e) {
        e.preventDefault();
        console.log(1);
        e.stopPropagation();
    });
})();